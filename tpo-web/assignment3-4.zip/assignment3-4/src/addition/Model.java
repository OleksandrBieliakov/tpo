package addition;

public class Model {

    private String result;

    public Model(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }

}
